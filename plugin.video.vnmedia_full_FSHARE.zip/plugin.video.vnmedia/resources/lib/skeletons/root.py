root = None
menu = {
    'fshare': {
        'route': '/resources/lib/mkd/fshare:index_fshare',
        'label': 'Fshare',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare.png',
        'enabled': True,
        'order': 1
    },
    'ytube': {
        'route': '/resources/lib/mkd/ytube:index_youtube',
        'label': 'Youtube',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/youtube.png',
        'enabled': True,
        'order': 2
    },
    'truyenhinh': {
        'route': '/resources/lib/mkd/truyenhinh:listiptv_root',
        'label': 'Truyền hình - IPTV xem phim',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/truyenhinh.png',
        'enabled': True,
        'order': 3
    },
    'thethao': {
        'route': '/resources/lib/main:generic_menu',
        'label': 'Thể thao',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao.png',
        'enabled': True,
        'order': 4
    },
    'tintuc': {
        'route': '/resources/lib/mkd/tintuc:index_tintuc',
        'label': 'Tin tức',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/tintuc.png',
        'enabled': True,
        'order': 5
    },
    'amnhac': {
        'route': '/resources/lib/mkd/nhac:index_amnhac',
        'label': 'Âm nhạc',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/amnhac.png',
        'enabled': True,
        'order': 6
    },
    'thieunhi': {
        'route': '/resources/lib/mkd/thieunhi:index_thieunhi',
        'label': 'Thiếu nhi',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thieunhi.png',
        'enabled': True,
        'order': 7
    },
    'giaitri': {
        'route': '/resources/lib/mkd/giaitri:index_giaitri',
        'label': 'Giải trí',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/giaitri.png',
        'enabled': True,
        'order': 8
    },
    'gcs': {
        'route': '/resources/lib/mkd/onfshare/gcs:index_gcs',
        'label': 'Góc chia sẻ',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/gocchiase.png',
        'enabled': True,
        'order': 9
    },
    'pmp': {
        'route': '/resources/lib/mkd/onphim/ophim:index_ophim',
        'label': 'Phim miễn phí',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phimmienphi.png',
        'enabled': True,
        'order': 10
    },
    'tienich': {
        'route': '/resources/lib/mkd/tienich:index_tienich',
        'label': 'Tiện ích',
        'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/tienich.png',
        'enabled': True,
        'order': 11
    }
}