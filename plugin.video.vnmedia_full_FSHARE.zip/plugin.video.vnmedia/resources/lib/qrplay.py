from codequick import Script, Route, Listitem, Resolver
from resources.lib.kedon import getrow, getlinkphongblack, postlinktimfs, getlinkvnm, __addonnoti__, tb, yttk, quangcao, basicfs
from resources.lib.mkd.onfshare.gcs import set_item_callbacks
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
from json import loads
from functools import lru_cache
import xbmc, random, requests, re
@lru_cache(maxsize=None)
def get_tkfs1(search_query):
    try:
        return getlinkphongblack(f'http://phongblack.me/search.php?author=phongblack&search={search_query}', 'http://www.google.com', -1)
    except:
        return getlinkphongblack(f'http://kodi.s2lsolutions.com/search.php?author=phongblack&search={search_query}', 'http://www.google.com', -1)
@lru_cache(maxsize=None)
def get_tkfs2(search_query):
    return postlinktimfs(f'http://api.timfshare.com/v1/string-query-search?query={search_query}', 'https://timfshare.com/', -1)
@lru_cache(maxsize=None)
def get_tkfs3(search_query):
    return getlinkvnm(f'http://thuvienhd.com/?feed=fsharejson&search={search_query}', 'https://thuvienhd.com/')
@lru_cache(maxsize=None)
def get_tkfs4():
    return getlinkvnm(f'http://thuvienhd.com/?feed=fsharejson&search=', 'https://thuvienhd.com/')
@Route.register
def qrplay(plugin, **kwargs):
    yield []
    my_number = random.randint(10000, 99999)
    url = 'https://docs.google.com/spreadsheets/d/11kmgd4cK8Kj7bJ8e8rGfYmgNxUvb1nQWN9S0y-4M3JQ/gviz/tq?gid=1028412373&headers=1'
    dialog = DialogProgress()
    dialog.create(f'[B][COLOR yellow]{my_number}[/COLOR][/B]', 'Đang lấy dữ liệu...')
    countdown = 200
    timeout_expired = False
    while countdown > 0:
        if dialog.iscanceled():
            dialog.close()
            yield quangcao()
            break
        resp = requests.get(url)
        if f'"{my_number}"' in resp.text:
            dialog.close()
            noi = re.search(r'\{.*\}', resp.text)[0]
            m = loads(noi)
            rows = m['table']['rows']
            for row in rows:
                kenh = getrow(row['c'][1])
                ten = getrow(row['c'][2])
                if ten == my_number:
                    if 'http' in kenh:
                        if 'fshare.vn/' in kenh:
                            item = Listitem()
                            item.label = basicfs(kenh)
                            set_item_callbacks(item, kenh, item.label)
                            yield item
                        else:
                            item = Listitem()
                            item.label = f'[COLOR yellow]Play[/COLOR]-{kenh}'
                            item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), kenh, kenh, '')
                            yield item
                    else:
                        search_query = quote_plus(kenh)
                        dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
                        with ThreadPoolExecutor(4) as ex:
                            f1 = ex.submit(get_tkfs1, search_query)
                            f2 = ex.submit(get_tkfs2, search_query)
                            f3 = ex.submit(get_tkfs3, search_query)
                            f4 = ex.submit(get_tkfs4)
                            result_f1 = f1.result()
                            result_f2 = f2.result()
                            result_f3 = f3.result()
                            result_f4 = f4.result()
                        dialog.update(50)
                        try:
                            if result_f3 is not None and result_f4 is not None:
                                if f3.result().content != f4.result().content:
                                    kqtvhd = f3.result().json()
                                    for t in kqtvhd:
                                        item = Listitem()
                                        item.label = t['title']
                                        item.info['plot'] = f'{t["title"]}\n{tb}'
                                        item.info['mediatype'] = 'episode'
                                        item.info['rating'] = 10.0
                                        item.info['trailer'] = yttk(item.label)
                                        item.art['thumb'] = item.art['fanart'] = t['image']
                                        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
                                        yield item
                        except:
                            if result_f3 is not None and result_f4 is not None:
                                if f3.result().content != f4.result().content:
                                    text = f3.result().text
                                    data = re.sub(r'<(.*?)\n','',text)
                                    jsm = loads(data)
                                    for t in jsm:
                                        item = Listitem()
                                        item.label = t['title']
                                        item.info['plot'] = f'{t["title"]}\n{tb}'
                                        item.info['mediatype'] = 'episode'
                                        item.info['rating'] = 10.0
                                        item.info['trailer'] = yttk(item.label)
                                        item.art['thumb'] = item.art['fanart'] = t['image']
                                        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
                                        yield item
                        try:
                            x = result_f1.json()['items']
                            for m in x:
                                mota = f"{m['info']['plot']}\n{tb}" if 'info' in m else tb
                                path = m['path']
                                if '/file/' in path:
                                    item = Listitem()
                                    item.label = m['label']
                                    link = path.split('&url=')[1]
                                    item.info['mediatype'] = 'episode'
                                    item.info['rating'] = 10.0
                                    item.info['trailer'] = yttk(item.label)
                                    item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={path.split("&url=")[1]}&qzone=1&margin=1&size=400x400&ecc=L'
                                    item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
                                    item.info['plot'] = mota
                                    if Addon().getSetting('taifshare') == 'true':
                                        item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
                                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
                                    item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
                                    yield item
                                elif '/folder/' in path:
                                    item = Listitem()
                                    item.label = m['label']
                                    link = path.split("&url=")[1]
                                    item.info['mediatype'] = 'episode'
                                    item.info['rating'] = 10.0
                                    item.info['trailer'] = yttk(item.label)
                                    item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={path.split("&url=")[1]}&qzone=1&margin=1&size=400x400&ecc=L'
                                    item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
                                    item.info['plot'] = mota
                                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
                                    item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
                                    yield item
                        except:
                            try:
                                kq = result_f2.json()
                                m = [k for k in kq['data'] if 'data' in kq]
                                for k in m:
                                    item = Listitem()
                                    item.label = k['name']
                                    item.info['plot'] = tb
                                    item.info['mediatype'] = 'episode'
                                    item.info['rating'] = 10.0
                                    item.info['trailer'] = yttk(item.label)
                                    item.art['thumb'] = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={k['url']}&qzone=1&margin=1&size=400x400&ecc=L"
                                    item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
                                    item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
                                    if 'folder' in k['url']:
                                        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), k['url'], 0)
                                    else:
                                        item.info['size'] = k['size']
                                        if Addon().getSetting('taifshare') == 'true':
                                            item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', k['url'])
                                        item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), k['url'], item.label)
                                    yield item
                            except:
                                pass
                        dialog.update(100)
                        dialog.close()
            break
        else:
            countdown -= 1
            dialog.update(int(((200-countdown)/200)*100), f'Mã liên kết: [COLOR yellow][B]{my_number}[/B][/COLOR] - Thời gian chờ: [COLOR orange][B]{countdown}[/B][/COLOR] giây[CR]Vào trang [COLOR yellow][B]http://mi3s.top[/B][/COLOR] nhập từ khóa tìm kiếm hoặc linkplay')
            xbmc.sleep(1000)
            if countdown == 0:
                timeout_expired = True
    if timeout_expired:
        yield quangcao()
    dialog.close()