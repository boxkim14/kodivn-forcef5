from codequick import Route, Listitem
from datetime import date, timedelta
@Route.register
def index_vtv(plugin, **kwargs):
	item = Listitem()
	item.label = 'Hôm nay'
	item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item.set_callback(list_vtv, date.today(), item.label, date.today())
	item1 = Listitem()
	item1.label = 'Hôm qua'
	item1.art['thumb'] = item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item1.set_callback(list_vtv, date.today() - timedelta(days = 1), item1.label, date.today() - timedelta(days = 1))
	item2 = Listitem()
	item2.label = 'Hôm kia'
	item2.art['thumb'] = item2.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
	item2.set_callback(list_vtv, date.today() - timedelta(days = 2), item2.label, date.today() - timedelta(days = 2))
	yield item
	yield item1
	yield item2
@Route.register
def list_vtv(plugin, tg=None, ngay=None, hom=None, **kwargs):
	yield []
	if tg is None or ngay is None or hom is None:
		pass
	else:
		kenhidvt = {
		'VTV1': '2',
		'VTV2': '3',
		'VTV3': '4',
		'VTV5': '110',
		'VTV Cần Thơ': '98',
		'VTC1': '16',
		'ANTV': '20',
		'Quốc hội': '290',
		'Vnews': '24',
		'Hà Nội 1': '33',
		'Sự kiện 1': '2554',
		'Sự kiện 2':'1',
		'Sự kiện 3':'148',
		'Sự kiện 4':'2458'}
		kenhidx = {
		'THVL1': 'thvl1',
		'THVL2': 'thvl2',
		'THVL3': 'thvl3',
		'THVL4': 'thvl4'}
		for m in kenhidvt:
			item = Listitem()
			item.label = m
			item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
			item.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/replaythvl:get_vtvvt'), kenhidvt[m], hom)
			yield item
		for l in kenhidx:
			item1 = Listitem()
			item1.label = l
			item1.art['thumb'] = item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
			item1.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/replaythvl:get_thvl'), kenhidx[l], hom)
			yield item1