from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, quangcao, stream, referer, useragentdf
from datetime import datetime
from functools import lru_cache
from requests import Session
@Route.register
def get_thvl(plugin, ten=None, hom=None, **kwargs):
	yield []
	if ten is None or hom is None:
		pass
	else:
		idk_dict = {'thvl1': 'aab94d1f-44e1-4992-8633-6d46da08db42',
			'thvl2': 'bc60bddb-99ac-416e-be26-eb4d0852f5cc',
			'thvl3': 'f2ad2726-d315-4612-b78d-746721788fc8',
			'thvl4': '442692d6-c296-4835-b060-72c4cd235bd2'}
		idk = idk_dict.get(ten, None)
		url = f'http://api.thvli.vn/backend/cm/epg/?channel_id={idk}&platform=web&schedule_date={hom}'
		resp = getlinkvnm(url, url)
		if (resp is not None) and ('items' in resp.text):
			m = [k for k in resp.json()['items'] if '.m3u8' in str(k['link_play'])]
			for k in m:
				item = Listitem()
				tg = datetime.fromtimestamp(k['start_at']).strftime('%H:%M')
				item.label = f'{tg} {hom}: {k["title"]}'
				linkplay = stream(str(k['link_play']))
				item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, '')
				yield item
		else:
			yield quangcao()
@Route.register
def get_vtvvt(plugin, ten=None, hom=None, **kwargs):
	yield []
	if ten is None or hom is None:
		pass
	else:
		idk_dict = {'3': 'dac12e23-ebcc-4c69-aaf5-5b2b8d47c41f/catchup/VTV2-1080-3_6M/VTV2-1080-3_6M',
			'4': 'f86bb850-f6ef-4c9d-b0ad-b8fe16ef27e9/catchup/1080p-5M/1080p-5M',
			'110': '6f862904-7894-4fbb-9707-f56e4fe10d63/catchup/VTV5-HD-50fps-1080P-65M/VTV5-HD-50fps-1080P-65M',
			'98': 'd055b75f-05c9-4799-8581-c46b60b878dd/catchup/720p/720p',
			'16':'331df74c-5a8e-4a1e-89f7-a2ded88a0714/catchup/1080p/1080p',
			'2554': '59cd98d4-a7c2-46f1-9c2a-f801c05fcb83/catchup/1080p-5M/1080p-5M',
			'2': '9754d403-01df-4fda-b506-a79f66f70b39/catchup/1080p/1080p',
			'20': 'f8545e62-e83e-42e3-a5db-c6c28b0410c1/catchup/480p1p6/480p1p6',
			'290': '2ec6b129-9efe-462c-be85-70933db7500a/catchup/1080p/1080p',
			'24': '8d2284ad-9069-49c0-87c7-204239402b9e/catchup/360p/360p',
			'1':'38726d63-bf42-43b1-b622-cf6d5b72e32d/catchup/U23-dubaicup2-360p/U23-dubaicup2-360p',
			'148':'72a19b7a-318c-4ae0-8a28-0f8841aea78f/catchup/1080p/1080p',
			'2458':'b8c5204f-cdf5-4d21-8659-a03f938a5b34/catchup/1080p/1080p',
			'33':'933e50c5-373c-431f-ae7f-be711442f516/catchup/480p1p6/480p1p6'}
		idk = idk_dict.get(ten, None)
		url = f'http://api.tv360.vn/public/v1/live/get-live-schedule?id={ten}&datetime={hom}'
		resp = getlinkvnm(url, url)
		if (resp is not None) and ('duration' in resp.text):
			for k in resp.json()['data']['schedules']:
				item = Listitem()
				doi = f"{k['datetime']} {k['startTime']}"
				timebd = int(datetime.strptime(doi, '%Y-%m-%d %H:%M').timestamp())
				linkget = f"http:///live-ali2.tv360.vn/manifest/{idk}.m3u8?media=true&start={timebd}&stop={timebd + k['duration']}"
				item.label = f"{k['startTime']} {k['date']}: {k['name']}"
				item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(linkget)}{referer("http://tv360.vn/")}', item.label, '')
				yield item
		else:
			yield quangcao()
@lru_cache(maxsize=None)
def get360(url):
	with Session() as s:
		site = s.get('http://tv360.vn/', headers={'user-agent': useragentdf,'referer': 'http://tv360.vn/'.encode('utf-8')})
		r = s.get(url)
		return r