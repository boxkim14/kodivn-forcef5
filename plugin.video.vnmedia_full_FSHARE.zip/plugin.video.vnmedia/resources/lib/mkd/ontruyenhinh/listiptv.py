from codequick import Route, Listitem, Resolver
from resources.lib.kedon import tb, ace, streamiptv, useragentott, referer, quangcao, getlinkip
from functools import lru_cache
import re
@Route.register
def list_iptv(plugin, url=None, **kwargs):
	yield []
	if url is None:
		pass
	else:
		item = Listitem()
		item.label = 'TẤT CẢ CÁC KÊNH'
		item.info['plot'] = "THÔNG BÁO tất cả các kênh"
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/truyenhinh.png'
		item.set_callback(little_iptv, url)
		yield item
		try:
			group = re.findall(r'group-title="(.*?)"', texturl(url))
			um = []
			for tk in list(dict.fromkeys(group)):
				[um.append(k) for k in tk.split(';') if k not in um] if ';' in tk else um.append(tk)
			if '' in um:
				um.remove('')
			for p in um:
				item = Listitem()
				item.label = p
				item.info['plot'] = "Thông báo gì đó"
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/truyenhinh.png'
				item.set_callback(info_iptv, url, item.label)
				yield item
		except:
			pass
@Route.register
def info_iptv(plugin, url=None, tk=None, **kwargs):
	yield []
	if url is None or tk is None:
		pass
	else:
		ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl(url)).split('#EXTINF')
		sre1 = re.compile(r'\n((http|https|udp|rtp|acestream):(.*?)\n)')
		sre2 = re.compile(r'[,](?!.*[,])(.*)')
		sre4 = re.compile(r'tvg-logo="(.*?)"')
		sre5 = re.compile(r'http-user-agent=(.*?)\n')
		sre6 = re.compile(r'http-referrer=(.*?)\n')
		sre7 = re.compile(r'license_key=(.*?)\n')
		for kq in ketqua:
			try:
				s1 = sre1.search(kq)
				s2 = sre2.search(kq)
				s4 = sre4.search(kq)
				s5 = sre5.search(kq)
				s6 = sre6.search(kq)
				s7 = sre7.search(kq)
				if f'group-title="{tk}"' in kq and ';' not in kq and s1:
					item = Listitem()
					kenh = s1[1]
					item.label = s2[1]
					item.info['plot'] = tb
					if s4:
						item.art['thumb'] = item.art['fanart'] = s4[1]
					else:
						item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/truyenhinh.png'
					if 'acestream' in kenh or ':6878' in kenh:
						item.path = ace(kenh, item.label)
						item.set_callback(item.path)
					else:
						user = s5[1] if s5 else useragentott
						linkplay = f'{streamiptv(kenh.strip(), user)}{referer(s6[1])}' if s6 else streamiptv(kenh.strip(), user)
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, s7[1]) if s7 else item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, '')
					yield item
				elif tk in kq and ';' in kq and s1:
					item = Listitem()
					kenh = s1[1]
					item.label = s2[1]
					item.info['plot'] = tb
					if s4:
						item.art['thumb'] = item.art['fanart'] = s4[1]
					else:
						item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/truyenhinh.png'
					if 'acestream' in kenh or ':6878' in kenh:
						item.path = ace(kenh, item.label)
						item.set_callback(item.path)
					else:
						user = s5[1] if s5 else useragentott
						linkplay = f'{streamiptv(kenh.strip(), user)}{referer(s6[1])}' if s6 else streamiptv(kenh.strip(), user)
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, s7[1]) if s7 else item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, '')
					yield item
			except:
				yield quangcao()
@Route.register
def little_iptv(plugin, url=None, **kwargs):
	yield []
	if url is None:
		pass
	else:
		ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl(url)).split('#EXTINF')
		sre1 = re.compile(r'\n((http|https|udp|rtp|acestream):(.*?)\n)')
		sre2 = re.compile(r'[,](?!.*[,])(.*)')
		sre3 = re.compile(r'group-title="(.*?)"')
		sre4 = re.compile(r'tvg-logo="(.*?)"')
		sre5 = re.compile(r'http-user-agent=(.*?)\n')
		sre6 = re.compile(r'http-referrer=(.*?)\n')
		sre7 = re.compile(r'license_key=(.*?)\n')
		for kq in ketqua:
			try:
				s2 = sre2.search(kq)
				s3 = sre3.search(kq)
				s5 = sre5.search(kq)
				s6 = sre6.search(kq)
				s7 = sre7.search(kq)
				if s1:= sre1.search(kq):
					item = Listitem()
					kenh = s1[1]
					tenkenh = s2[1]
					nhomkenh = s3[1] if s3 else 'TỔNG HỢP'
					item.info['plot'] = f'{nhomkenh} - {tenkenh}'
					item.label = f'{tenkenh} - {nhomkenh}'
					if s4:= sre4.search(kq):
						item.art['thumb'] = item.art['fanart'] = s4[1]
					else:
						item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/truyenhinh.png'
					if 'acestream' in kenh or ':6878' in kenh:
						item.path = ace(kenh, item.label)
						item.set_callback(item.path)
					else:
						user = s5[1] if s5 else useragentott
						linkplay = f'{streamiptv(kenh.strip(), user)}{referer(s6[1])}' if s6 else streamiptv(kenh.strip(), user)
						item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, s7[1])if s7 else item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linkplay, item.label, '')
					yield item
			except:
				yield quangcao()
@lru_cache(maxsize=None)
def texturl(url):
	return getlinkip(url, url).data.decode('utf-8')