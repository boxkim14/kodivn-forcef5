from codequick import Route, Listitem, Resolver
from resources.lib.kedon import fu, getlinkvnm, tb, quangcao
from json import loads
from calendar import timegm
from time import gmtime
import re
@Route.register
def index_socolive(plugin, **kwargs):
	yield []
	linkref = fu('http://bit.ly/socolive')
	timestamp = timegm(gmtime())
	url = f'http://json.vnres.co/all_live_rooms.json?v={timestamp}'
	resp = getlinkvnm(url, url)
	if (resp is not None):
		nd = re.search(r'(\{.*\})', resp.text, re.DOTALL)[1]
		m = loads(nd)
		for k in m['data']['hot']:
			item = Listitem()
			item.label = f'{k["title"]} ({k["anchor"]["nickName"]})'
			item.art['thumb'] = item.art['fanart'] = k['cover']
			item.info['plot'] = f'{k["notice"]}\n{tb}'
			item.set_callback(Resolver.ref('/resources/lib/kedon:playsocolive'), k['roomNum'], timestamp, linkref, item.label)
			yield item
	else:
		yield quangcao()