from codequick import Route, Listitem, Resolver
from resources.lib.kedon import fu, getlink, quangcao
from urllib.parse import urlparse
from bs4 import BeautifulSoup
from functools import lru_cache
import re
@lru_cache(maxsize=None)
def mitom():
	url = 'http://bit.ly/m/xoilac'
	response = getlink(url, url, 1000)
	matches = re.findall(r'\{"target": "([^"]+)(.*?)\}', response.text)
	filtered_matches = [match for match in matches if 'mitom' in match[1].lower()]
	if filtered_matches:
		mitom_url = filtered_matches[0][0]
		if 'http' not in mitom_url:
			mitom_url = f'http://{mitom_url}'
		return mitom_url
	return None
@lru_cache(maxsize=None)
def format_match_text(match_text):
	if '(' in match_text:
		time_date = match_text.split("(")[-1].rstrip(")")
		team_names = match_text.rsplit("(", 1)[0].strip()
		return f"{time_date} {team_names}"
	else:
		return match_text
@Route.register
def index_91phut(plugin, **kwargs):
	yield []
	v = urlparse(fu(mitom()))
	url = f'{v.scheme}://{v.netloc}/vb-ajax.php?action=filter_match&filter=all&league='
	resp = getlink(url, url, 1000)
	if (resp is not None):
		soup = BeautifulSoup(resp.json()['data']['html'], 'html.parser')
		for episode in soup.select('div.position-relative.match'):
			item = Listitem()
			name = episode.select_one('a.link-match').get('title')
			try:
				ten = f"[B]{format_match_text(name)} ({episode.select_one('span.text-ellipsis').get_text(strip=True)})[/B]"
			except:
				ten = format_match_text(name)
			item.label = f'[COLOR yellow]{ten}[/COLOR]' if '"hot"' in str(episode) else ten
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/mitom.png'
			item.set_callback(list_91phut, episode.select_one('a.link-match').get('href'), item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_91phut(plugin, url=None, title=None, **kwargs):
	yield []
	if url is None or title is None:
		pass
	else:
		resp = getlink(url, url, 400)
		if (resp is not None):
			soup = BeautifulSoup(resp.content, 'html.parser')
			for episode in soup.select('div.link-video a'):
				item = Listitem()
				item.label = f'{episode.get_text(strip=True)} - {title}'
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/mitom.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_bongda'), episode.get('href'), item.label)
				yield item
		else:
			yield quangcao()