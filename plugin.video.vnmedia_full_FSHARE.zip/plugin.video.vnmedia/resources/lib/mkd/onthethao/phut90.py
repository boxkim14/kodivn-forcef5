from codequick import Route, Listitem, Resolver
from resources.lib.kedon import u90, getlinkvnm, tb, quangcao, getlink, referer, stream, qc
from datetime import datetime
from functools import lru_cache
import re, sys
@lru_cache(maxsize=None)
def respphut90():
	tr = f"https://{u90('90')}"
	resp90 = getlinkvnm(tr, tr)
	if (resp90 is not None):
		html_content = re.sub(r"(\n\s*//.*)", "", resp90.text)
		ref = re.search(r'base_embed_url\s*=\s*("|\')([^"\s]+)("|\')', html_content)[2]
	else:
		ref = tr
	return ref
@Route.register
def index_90p(plugin, **kwargs):
	yield []
	resp = getlinkvnm('https://api.vebo.xyz/api/match/featured/mt', f"https://{u90('90')}")
	if (resp is not None):
		for k in resp.json()['data']:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			ten = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})' if k['commentators'] else f'{time}: {k["name"]}'
			ten = f'[B]{ten}[/B]' if k['match_status'] == 'live' else ten
			item.label = f'[COLOR yellow]{ten}[/COLOR]' if (k['is_featured'] or k['tournament']['unique_tournament']['is_featured']) else ten
			item.info['plot'] = tb
			logotour = k['tournament']['logo']
			if logotour:
				item.art['thumb'] = item.art['fanart'] = logotour
			else:
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/vebo.png'
			item.set_callback(list_90p, k['id'], item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_90p(plugin, idk=None, title=None, **kwargs):
	yield []
	if idk is None or title is None:
		pass
	else:
		ref = respphut90()
		url = f'http://api.vebo.xyz/api/match/{idk}/meta'
		resp = getlinkvnm(url, url)
		if (resp is not None) and ('.m3u8' in resp.text):
			kq = resp.json()
			for k in kq['data']['play_urls']:
				item = Listitem()
				item.label = f'{k["name"]} - {title}'
				item.info['plot'] = tb
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/90p.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(k["url"])}{referer(ref)}', item.label, '')
				yield item
		else:
			yield quangcao()
@Route.register
def xemlai_90p(plugin, pl=None, page=None, **kwargs):
	yield []
	if pl is None or page is None:
		pass
	else:
		ref = respphut90()
		url = f'https://api.vebo.xyz/api/news/mitom/list/{pl}/{page}'
		resp = getlink(url, ref, 1000)
		if (resp is not None):
			kq = resp.json()
			if f:= kq['data']['highlight']:
				item = Listitem()
				item.label = f['name']
				item.info['plot'] = tb
				item.art['thumb'] = item.art['fanart'] = f['feature_image']
				item.set_callback(list_xemlai90p, f"https://api.vebo.xyz/api/news/mitom/detail/{f['id']}", ref, item.label)
				yield item
			for k in kq['data']['list']:
				item1 = Listitem()
				item1.label = k["name"]
				item1.info['plot'] = tb
				item1.art['thumb'] = item1.art['fanart'] = k['feature_image']
				item1.set_callback(list_xemlai90p, f"https://api.vebo.xyz/api/news/mitom/detail/{k['id']}", ref, item1.label)
				yield item1
			item2 = Listitem()
			item2.label = f'Trang {page + 1}'
			item2.info['plot'] = tb
			item2.art['thumb'] = item2.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
			item2.set_callback(xemlai_90p, pl, page + 1)
			yield item2
		else:
			yield quangcao()
@Resolver.register
def list_xemlai90p(plugin, url, ref, title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	r = getlink(url, url, 1000)
	if (r is not None) and ('.m3u8' in r.text):
		match = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', r.text)
		d = f'{stream(match[1])}{referer(ref)}'.split('|')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})
def create_list_item(k2, is_featured):
	item2 = Listitem()
	time = datetime.fromtimestamp(int(k2['timestamp'])/1000).strftime('%H:%M %d-%m')
	if k2['commentators']:
		item2.label = f'{time}: {k2["name"]} ({k2["commentators"][0]["name"]})'
	else:
		item2.label = f'{time}: {k2["name"]}'
	item2.info['plot'] = tb
	logotour2 = k2['tournament']['logo']
	if logotour2:
		item2.art['thumb'] = item2.art['fanart'] = logotour2
	else:
		item2.art['thumb'] = item2.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/vebo.png'
	item2.set_callback(list_90p, k2['id'], item2.label)
	return item2