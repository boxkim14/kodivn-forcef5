from codequick import Route, Listitem, Resolver
from resources.lib.kedon import u90, getlinkvnm, tb, quangcao, getlink, referer, stream
from datetime import datetime
import re, sys
@Route.register
def index_bc(plugin, **kwargs):
	yield []
	resp = getlinkvnm(f'https://api.{u90("bongcam")}/v2/match/featured', f"https://{u90('bongcam')}")
	if (resp is not None):
		for k in resp.json()['data']:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			ten = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})' if k['commentators'] else f'{time}: {k["name"]}'
			ten = f'[B]{ten}[/B]' if k['match_status'] == 'live' else ten
			item.label = f'[COLOR yellow]{ten}[/COLOR]' if k['tournament']['is_featured'] else ten
			item.info['plot'] = tb
			logotour = k['tournament']['logo']
			if logotour:
				item.art['thumb'] = item.art['fanart'] = logotour
			else:
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/nba.png'
			item.set_callback(list_bc, k['id'], item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_bc(plugin, idk=None, title=None, **kwargs):
	yield []
	if idk is None or title is None:
		pass
	else:
		url = f'https://{u90("bongcam")}/truc-tiep/mkendo-{idk}'
		resp = getlink(url, url, 300)
		if (resp is not None) and ('.m3u8' in resp.text):
			html_content = re.sub(r"(\n\s*//.*)", "", resp.text)
			ref = re.search(r'let base\s*=\s*("|\')([^"\s]+)("|\')', html_content)[2]
			urls_and_names = re.findall(r'"url":"(.*?)".*?"name":"(.*?)"', resp.text)
			result = {name: url for url, name in urls_and_names}
			for name, urlplay in result.items():
				item = Listitem()
				item.label = f'{name} - {title}'
				item.info['plot'] = tb
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/nba.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(urlplay)}{referer(ref)}', item.label, '')
				yield item
		else:
			yield quangcao()