from codequick import Route, Listitem, Script
from functools import lru_cache
@Route.register
def index_xemlaivk(plugin, **kwargs):
	yield xemlainhanhmt()
	yield xemlai90pmt()
	yield xemlai90ptc()
	yield xemlaifs()
@lru_cache(maxsize=None)
def xemlai90pmt():
	item = Listitem()
	item.label = 'Replay Sport - TIENGRUOI'
	item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/fullmatch.png'
	item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
	item.set_callback(Route.ref('/resources/lib/mkd/onthethao/phut90:xemlai_90p'), 'xemlai', 1)
	return item
@lru_cache(maxsize=None)
def xemlai90ptc():
	item = Listitem()
	item.label = 'Replay Sport - THAPCAM'
	item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/fullmatch.png'
	item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
	item.set_callback(Route.ref('/resources/lib/mkd/onthethao/thapcam:xemlai_tc'), 1)
	return item
@lru_cache(maxsize=None)
def xemlaifs():
	item = Listitem()
	item.label = 'Replay Sport - Fshare'
	link = 'https://www.fshare.vn/folder/JYXLS1FR9QP2'
	item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/uhd.png'
	item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
	item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
	item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
	return item
@lru_cache(maxsize=None)
def xemlainhanhmt():
	item = Listitem()
	item.label = 'Tóm tắt trận đấu - TIENGRUOI'
	item.art['thumb'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/highlights.png'
	item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
	item.set_callback(Route.ref('/resources/lib/mkd/onthethao/phut90:xemlai_90p'), 'highlight', 1)
	return item