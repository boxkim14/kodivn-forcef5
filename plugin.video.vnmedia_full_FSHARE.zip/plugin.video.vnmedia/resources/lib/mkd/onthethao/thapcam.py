from codequick import Route, Listitem, Resolver
from resources.lib.kedon import u90, getlink, getlinkvnm, tb, quangcao, stream, referer, qc
from datetime import datetime
from bs4 import BeautifulSoup
from functools import lru_cache
import re
def get_full_url(url):
	if url.startswith('/'):
		return f'https://{u90("thapcam")}{url}'
	else:
		return url
@lru_cache(maxsize=None)
def resptc():
	tr1 = f'https://{u90("thapcam")}/tc/js/main.js'
	resp90 = getlinkvnm(tr1, tr1)
	if (resp90 is not None):
		html_content = re.sub(r"(\n\s*//.*)", "", resp90.content.decode())
		ref = re.search(r'base_embed_url\s*=\s*("|\')([^"\s]+)("|\')', html_content)[2]
	else:
		ref = tr1
	return ref
@Route.register
def index_thapcam(plugin, **kwargs):
	yield []
	resp = getlinkvnm('https://api.thapcam.xyz/api/match/featured/mt', f"https://{u90('thapcam')}")
	if (resp is not None):
		for k in resp.json()['data']:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			ten = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})' if k['commentators'] else f'{time}: {k["name"]}'
			ten = f'[B]{ten}[/B]' if k['match_status'] == 'live' else ten
			item.label = f'[COLOR yellow]{ten}[/COLOR]' if (k['is_featured'] or k['tournament']['unique_tournament']['is_featured']) else ten
			item.info['plot'] = tb
			logotour = k['tournament']['logo']
			if logotour:
				item.art['thumb'] = item.art['fanart'] = logotour
			else:
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/thapcamtv.png'
			item.set_callback(list_thapcam, k['id'], item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_thapcam(plugin, idk=None, title=None, **kwargs):
	yield []
	if idk is None or title is None:
		pass
	else:
		ref = resptc()
		url = f'http://api.thapcam.xyz/api/match/{idk}/meta'
		resp = getlinkvnm(url, ref)
		if (resp is not None) and ('.m3u8' in resp.text):
			kq = resp.json()
			for k in kq['data']['play_urls']:
				item = Listitem()
				item.label = f'{k["name"]} - {title}'
				linktrandau = f'{stream(k["url"])}{referer(ref)}'
				item.info['plot'] = tb
				item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/thethao/thapcamtv.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linktrandau, item.label, '')
				yield item
		else:
			yield quangcao()
@Route.register
def xemlai_tc(plugin, page=None, **kwargs):
	yield []
	if page is None:
		pass
	else:
		ref = resptc()
		url = f'https://{u90("thapcam")}/xem-lai' if page==1 else f'https://{u90("thapcam")}/xem-lai/trang-{page}'
		resp = getlink(url, ref, 1000)
		if (resp is not None) and ('news-title' in resp.text):
			soup = BeautifulSoup(resp.content, 'html.parser')
			for k in soup.select('div.box-content div.news-big'):
				item = Listitem()
				item.label = k.select_one('h4.news-title a').get_text(strip=True)
				item.info['plot'] = tb
				item.art['thumb'] = item.art['fanart'] = k.select_one('a.news-thumb img').get('data-src')
				item.set_callback(list_xemlaitc, get_full_url(k.select_one('h4.news-title a').get('href')), ref, item.label)
				yield item
			for l in soup.select('div.box-content div.item.item-highlight'):
				item1 = Listitem()
				item1.label = l.select_one('h4.news-title a').get_text(strip=True)
				item1.info['plot'] = tb
				item1.art['thumb'] = item1.art['fanart'] = l.select_one('a.news-thumb img').get('data-src')
				item1.set_callback(list_xemlaitc, get_full_url(l.select_one('h4.news-title a').get('href')), ref, item1.label)
				yield item1
			if 'Trang tiếp' in resp.text:
				item2 = Listitem()
				item2.label = f'Trang {page + 1}'
				item2.info['plot'] = tb
				item2.art['thumb'] = item2.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
				item2.set_callback(xemlai_tc, page + 1)
				yield item2
		else:
			yield quangcao()
@Resolver.register
def list_xemlaitc(plugin, url, ref, title, **kwargs):
	news = 'http://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/qc.ass'
	r = getlink(url, url, 1000)
	if (r is not None) and ('.m3u8' in r.text):
		match = re.search(r'(https?://[^\s"]+\.m3u8[^"\']*)', r.text)
		d = f'{stream(match[1])}{referer(ref)}'.split('|')
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':d[0],'properties':{'inputstream.adaptive.manifest_type':'hls','inputstream.adaptive.manifest_headers': d[1],'inputstream.adaptive.stream_headers': d[1],'inputstream':'inputstream.adaptive'}})
	else:
		return Listitem().from_dict(**{'label':title,'subtitles':{news},'callback':qc()})