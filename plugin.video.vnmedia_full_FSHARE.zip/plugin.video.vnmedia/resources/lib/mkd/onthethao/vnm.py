from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, quangcao, tb
from urllib.parse import unquote
@Route.register
def index_vnm(plugin, **kwargs):
	yield []
	url = 'http://mi3s.top/vnmedia'
	resp = getlinkvnm(url, url)
	if resp is not None:
		tach = (r.rstrip().split('|') for r in resp.iter_lines(decode_unicode=True) if r.strip())
		for k in tach:
			item = Listitem()
			item.label = k[0]
			item.info['plot'] = tb
			item.art['thumb'] = item.art['fanart'] = k[3]
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), unquote(k[1]).strip(), item.label, '')
			yield item
	else:
		yield quangcao()