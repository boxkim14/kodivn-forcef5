from codequick import Route, Listitem, Script, Resolver
from resources.lib.kedon import __addonnoti__, getlink, quangcao, tb, yttk, get_info_fs
from bs4 import BeautifulSoup
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
from concurrent.futures import ThreadPoolExecutor, as_completed
import re
@Route.register
def search_thuvienhd(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		dp = DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		dp.update(5)
		sr = quote_plus(search_query)
		url = f'http://thuvienhd.com/?s={sr.replace(" ","+")}'
		urlrf = 'https://thuvienhd.com'
		resp = getlink(url, urlrf, 10000)
		if (resp is not None):
			match = re.search(r'"nonce":"(.*?)"', resp.text)[1]
			urltv = f'http://thuvienhd.com/wp-json/dooplay/search/?nonce={match}&keyword={sr}'
			r = getlink(urltv, urlrf, 10000)
			if 'No results' in r.text:
				yield quangcao()
			else:
				for k in r.json().values():
					item = Listitem()
					item.label = k['title']
					item.info['plot'] = tb
					item.info['mediatype'] = 'movie'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['fanart'] = k['img']
					item.set_callback(thuvienhd_linktk, k['url'])
					yield item
		else:
			yield quangcao()
		dp.update(100)
		dp.close()
@Route.register
def index_thuvienhd(plugin, **kwargs):
	yield []
	yield Listitem.search(search_thuvienhd)
	url = 'http://thuvienhd.com/'
	resp = getlink(url, url, 10000)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		b = [k for k in soup.select('ul.genres.falsescroll li a') if 'thuvienhd.com' in k.get('href')]
		for k in b:
			item = Listitem()
			item.label = k.get_text(strip=True)
			item.info['plot'] = tb
			item.art['thumb'] = item.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/tvhd.png'
			item.set_callback(thuvienhd_page, f'{k.get("href")}/page/', 1)
			yield item
	else:
		yield quangcao()
@Route.register
def thuvienhd_linktk(plugin, url=None, **kwargs):
	yield []
	if url is None:
		pass
	else:
		respx = getlink(url, url, 10000)
		if (respx is not None):
			idk = re.search(r"thuvienhd.com/\?p=(\d+)", respx.text)
			t = f'https://thuvienhd.com/?feed=fsharejson&id={idk[1]}'
			resp = getlink(t, t, 10000)
			if (resp is not None) and resp.json()['link']:
				d = resp.json()
				urls = [k['link'] for k in d['link'] if 'fshare.vn' in k['link']]
				length = len(urls)
				dialog = DialogProgress()
				dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
				dialog.update(5, f'Đang giải mã {length} dữ liệu...')
				if length>0:
					with ThreadPoolExecutor(length) as ex:
						future_to_url = {ex.submit(get_info_fs, url): url for url in urls}
						for future in as_completed(future_to_url):
							link = future_to_url[future]
							data = future.result()
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = d['description']
							item.info['mediatype'] = 'episode'
							item.info['rating'] = 10.0
							item.info['trailer'] = yttk(item.label)
							item.art['thumb'] = item.art['fanart'] = d['image']
							item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
							if 'folder' in link:
								item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
							else:
								item.info['size'] = data[1]
								if Addon().getSetting('taifshare') == 'true':
									item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
								item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
							yield item
							dialog.update(50)
				else:
					yield quangcao()
				dialog.update(100)
				dialog.close()
			else:
				yield quangcao()
		else:
			yield quangcao()
@Route.register
def thuvienhd_page(plugin, url=None, next_page=None, **kwargs):
	yield []
	if url is None or next_page is None:
		pass
	else:
		trangtiep = f'{url}{next_page}'
		resp = getlink(trangtiep, trangtiep, 5000)
		if (resp is not None):
			soup = BeautifulSoup(resp.content, 'html.parser')
			for episode in soup.select('div.items article'):
				item = Listitem()
				item.label = episode.select_one('img').get('alt')
				item.info['plot'] = f"{episode.select_one('div.texto').get_text(strip=True)}\n{tb}" if 'texto' in resp.text else tb
				item.info['mediatype'] = 'movie'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = item.art['fanart'] = episode.select_one('img').get('src')
				item.set_callback(thuvienhd_link, episode.get('id').split('-')[1])
				yield item
			for checkpage in soup.select('div.pagination a'):
				if str(next_page + 1) in checkpage.get_text(strip=True):
					item1 = Listitem()
					item1.label = f'Trang {next_page + 1}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item1.set_callback(thuvienhd_page, url, next_page + 1)
					yield item1
		else:
			yield quangcao()
@Route.register
def thuvienhd_link(plugin, idk=None, **kwargs):
	yield []
	if idk is None:
		pass
	else:
		t = f'https://thuvienhd.com/?feed=fsharejson&id={idk}'
		resp = getlink(t, t, 10000)
		if (resp is not None) and resp.json()['link']:
			d = resp.json()
			urls = [k['link'] for k in d['link'] if 'fshare.vn' in k['link']]
			length = len(urls)
			dialog = DialogProgress()
			dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
			dialog.update(5, f'Đang giải mã {length} dữ liệu...')
			if length>0:
				with ThreadPoolExecutor(length) as ex:
					future_to_url = {ex.submit(get_info_fs, url): url for url in urls}
					for future in as_completed(future_to_url):
						link = future_to_url[future]
						data = future.result()
						item = Listitem()
						item.label = data[0]
						item.info['plot'] = d['description']
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = item.art['fanart'] = d['image']
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						if 'folder' in link:
							item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
						else:
							item.info['size'] = data[1]
							if Addon().getSetting('taifshare') == 'true':
								item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
							item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
						yield item
						dialog.update(50)
			else:
				yield quangcao()
			dialog.update(100)
			dialog.close()
		else:
			yield quangcao()