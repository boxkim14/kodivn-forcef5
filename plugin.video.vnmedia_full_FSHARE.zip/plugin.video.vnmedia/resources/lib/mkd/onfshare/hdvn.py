from codequick import Route, Listitem, Resolver, Script
from bs4 import BeautifulSoup
from resources.lib.kedon import getlink, get_info_hdvn, __addonnoti__, fu, tb, yttk, quangcao, get_info_fs
from resources.lib.mkd.onfshare.ifshare import hdvn, likehdvn, loginfhdvn, tkhdvn
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import Dialog, DialogProgress
from xbmcaddon import Addon
from urllib.parse import quote_plus
from functools import lru_cache
from xbmc import getInfoLabel
import re
def is_not_number(a):
	if not a.isdigit():
		return True
	else:
		return False
@Route.register
def search_hdvn(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		search_query = quote_plus(search_query)
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		r = tkhdvn(search_query)
		if (r is not None) and ('titleText' in r.text) and ('pageNavHeader' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			tongtrang = re.findall(r"\d+", soup.select_one('span.pageNavHeader').get_text(strip=True))[-1]
			urls = [f"{hdvn}/{episode.get('href')}" for episode in soup.select('div.titleText a') if 'titleText' in r.text]
			length = len(urls)
			idsearch = re.search(r'search/([0-9]+)', r.url)[1]
			if length>0:
				dialog.update(5, f'Đang giải mã {length} dữ liệu...')
				if length>0:
					with ThreadPoolExecutor(length) as ex:
						future_to_url = {ex.submit(get_info_hdvn, url): url for url in urls}
						for future in as_completed(future_to_url):
							link = future_to_url[future]
							data = future.result()
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.info['rating'] = 10.0
							item.info['trailer'] = yttk(item.label)
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(hdvn_link, data[3])
							yield item
					if '>Tiếp' in r.text:
						item1 = Listitem()
						item1.label = f'Trang 2/{tongtrang}'
						item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
						item1.set_callback(search_hdvnnext, search_query, str('2'), idsearch)
						yield item1
					yield tktrangmoi(search_query, idsearch)
			dialog.update(50)
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
		dialog.update(100)
		dialog.close()
@Route.register
def search_hdvnnext(plugin, search_query=None, next_page=None, idsearch=None, **kwargs):
	yield []
	if search_query is None or next_page is None or idsearch is None:
		pass
	else:
		search_query = quote_plus(search_query)
		url = f'{hdvn}/search/{idsearch}/?page={next_page}&q={search_query.replace(" ","+")}&o=date'
		r = getlink(url, url, 7200)
		if (r is not None) and ('titleText' in r.text) and ('pageNavHeader' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			tongtrang = re.findall(r"\d+", soup.select_one('span.pageNavHeader').get_text(strip=True))[-1]
			urls = [f"{hdvn}/{episode.get('href')}" for episode in soup.select('div.titleText a') if 'titleText' in r.text]
			length = len(urls)
			if length>0:
				dialog = DialogProgress()
				dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
				dialog.update(5, f'Đang giải mã {length} dữ liệu...')
				with ThreadPoolExecutor(length) as ex:
					future_to_url = {ex.submit(get_info_hdvn, url): url for url in urls}
					for future in as_completed(future_to_url):
						link = future_to_url[future]
						data = future.result()
						item = Listitem()
						item.label = data[0]
						item.info['plot'] = data[2]
						item.info['mediatype'] = 'movie'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = item.art['fanart'] = data[1]
						item.set_callback(hdvn_link, data[3])
						yield item
				if '>Tiếp' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 1)}/{tongtrang}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item1.set_callback(search_hdvnnext, search_query, str(int(next_page) + 1), idsearch)
					yield item1
				yield tktrangmoi(search_query, idsearch)
			dialog.update(100)
			dialog.close()
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
@Route.register
def index_hdvn(plugin, **kwargs):
	H = {
	'4K': f'{hdvn}/forums/4k.337/',
	'WEB-DL, HDTV 4K': f'{hdvn}/forums/web-dl-hdtv-4k.344/',
	'Bluray Remux 4K': f'{hdvn}/forums/bluray-remux-4k.345/',
	'Bluray Nguyên Gốc 4K': f'{hdvn}/forums/bluray-nguyen-goc-4k.346/',
	'Fshare.vn': f'{hdvn}/forums/fshare-vn.33/',
	'Fshare-WEB-DL, HDTV': f'{hdvn}/forums/web-dl-hdtv.271/',
	'Fshare-Bluray Remux': f'{hdvn}/forums/bluray-remux.324/',
	'Fshare-mHD, SD': f'{hdvn}/forums/mhd-sd.77/',
	'Fshare-Bluray nguyên gốc': f'{hdvn}/forums/bluray-nguyen-goc.78/',
	'Thư viện link Phim': f'{hdvn}/forums/thu-vien-link-phim.150/',
	'Phim có audio Việt': f'{hdvn}/forums/phim-co-audio-viet.265/',
	'Phim bộ - Series': f'{hdvn}/forums/phim-bo-series.57/',
	'Phim bộ - mHD, SD': f'{hdvn}/forums/mhd-sd.104/',
	'Phim hoạt hình': f'{hdvn}/forums/phim-hoat-hinh.123/',
	'Phim hoạt hình - mHD, SD': f'{hdvn}/forums/mhd-sd.124/',
	'Phim tài liệu - Documentaries': f'{hdvn}/forums/phim-tai-lieu-documentaries.116/',
	'Phim 3D': f'{hdvn}/forums/3d.110/',
	'Phim cho iOS/Android': f'{hdvn}/forums/phim-cho-ios-android.157/',
	'Music request': f'{hdvn}/forums/music-request.28/',
	'HD Video Clip': f'{hdvn}/forums/hd-video-clip.50/',
	'Video nhạc US-EU': f'{hdvn}/forums/us-eu.189/',
	'Video nhạc Việt Nam': f'{hdvn}/forums/viet-nam.191/',
	'Video nhạc Asia': f'{hdvn}/forums/asia.190/',
	'Soundtrack': f'{hdvn}/forums/soundtrack.73/',
	'Lossless Albums': f'{hdvn}/forums/lossless-albums.26/',
	'Lossless Việt Nam': f'{hdvn}/forums/nhac-viet-nam.183/',
	'Lossless Quốc tế': f'{hdvn}/forums/nhac-quoc-te.184/',
	'Lossless không lời': f'{hdvn}/forums/nhac-khong-loi.185/',
	'Lossy albums': f'{hdvn}/forums/lossy-albums.27/',
	'mHD, SD Video Clips': f'{hdvn}/forums/mhd-sd-video-clips.25/'
	}
	yield Listitem.search(search_hdvn)
	for k in H:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuvienhd.png'
		item.info['plot'] = tb
		item.set_callback(hdvn_page, H[k], 1)
		yield item
	pass
@Route.register
def hdvn_page(plugin, url=None, next_page=None, **kwargs):
	yield []
	if url is None or next_page is None:
		pass
	else:
		trangtiep = f'{url}page-{next_page}'
		r = getlink(trangtiep, trangtiep, 14400)
		if (r is not None) and ('titleText' in r.text) and ('pageNavHeader' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			tongtrang = re.findall(r"\d+", soup.select_one('span.pageNavHeader').get_text(strip=True))[-1]
			urls = [f"{hdvn}/{episode.get('href')}" for episode in soup.select('a.PreviewTooltip')]
			length = len(urls)
			if length>0:
				dialog = DialogProgress()
				dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
				dialog.update(5, f'Đang giải mã {length} dữ liệu...')
				with ThreadPoolExecutor(length) as ex:
					future_to_url = {ex.submit(get_info_hdvn, url): url for url in urls}
					for future in as_completed(future_to_url):
						link = future_to_url[future]
						data = future.result()
						item = Listitem()
						item.label = data[0]
						item.info['plot'] = data[2]
						item.info['mediatype'] = 'movie'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = item.art['fanart'] = data[1]
						item.set_callback(hdvn_link, data[3])
						yield item
				if '>Tiếp' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 1)}/{tongtrang}'
					item1.info['plot'] = tb
					item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
					item1.set_callback(hdvn_page, url, str(int(next_page) + 1))
					yield item1
				yield trangmoi(url)
		else:
			yield quangcao()
		dialog.update(100)
		dialog.close()
@Route.register
def next_pagehdvn(plugin, url=None, **kwargs):
	yield []
	if url is None:
		pass
	else:
		next_page = Dialog().input('Nhập số trang')
		if not next_page or is_not_number(next_page):
			Script.notify(__addonnoti__, 'Bạn chưa nhập số trang')
			yield quangcao()
		else:
			dialog = DialogProgress()
			dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
			trangtiep = f'{url}page-{next_page}'
			r = getlink(trangtiep, trangtiep, 14400)
			if (r is not None) and ('titleText' in r.text) and ('pageNavHeader' in r.text):
				soup = BeautifulSoup(r.content, 'html.parser')
				tongtrang = re.findall(r"\d+", soup.select_one('span.pageNavHeader').get_text(strip=True))[-1]
				urls = [f"{hdvn}/{episode.get('href')}" for episode in soup.select('a.PreviewTooltip')]
				length = len(urls)
				if length>0:
					dialog.update(5, f'Đang giải mã {length} dữ liệu...')
					with ThreadPoolExecutor(length) as ex:
						future_to_url = {ex.submit(get_info_hdvn, url): url for url in urls}
						for future in as_completed(future_to_url):
							link = future_to_url[future]
							data = future.result()
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.info['rating'] = 10.0
							item.info['trailer'] = yttk(item.label)
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(hdvn_link, data[3])
							yield item
					if '>Tiếp' in r.text:
						item1 = Listitem()
						item1.label = f'Trang {str(int(next_page) + 1)}/{tongtrang}'
						item1.info['plot'] = tb
						item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
						item1.set_callback(hdvn_page, url, str(int(next_page) + 1))
						yield item1
					yield trangmoi(url)
			else:
				yield quangcao()
			dialog.update(100)
			dialog.close()
@Route.register
def next_searchhdvn(plugin, search_query=None, idsearch=None, **kwargs):
	yield []
	if search_query is None or idsearch is None:
		pass
	else:
		next_page = Dialog().input('Nhập số trang')
		if not next_page or is_not_number(next_page):
			Script.notify(__addonnoti__, 'Bạn chưa nhập số trang')
			yield quangcao()
		else:
			dialog = DialogProgress()
			dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
			trangtiep = f'{hdvn}/search/{idsearch}/?page={next_page}&q={search_query.replace(" ","+")}&o=date'
			r = getlink(trangtiep, trangtiep, 14400)
			if (r is not None) and ('titleText' in r.text) and ('pageNavHeader' in r.text):
				soup = BeautifulSoup(r.content, 'html.parser')
				tongtrang = re.findall(r"\d+", soup.select_one('span.pageNavHeader').get_text(strip=True))[-1]
				urls = [f"{hdvn}/{episode.get('href')}" for episode in soup.select('div.titleText a') if 'titleText' in r.text]
				length = len(urls)
				if length>0:
					dialog = DialogProgress()
					dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
					dialog.update(5, f'Đang giải mã {length} dữ liệu...')
					with ThreadPoolExecutor(length) as ex:
						future_to_url = {ex.submit(get_info_hdvn, url): url for url in urls}
						for future in as_completed(future_to_url):
							link = future_to_url[future]
							data = future.result()
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.info['rating'] = 10.0
							item.info['trailer'] = yttk(item.label)
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(hdvn_link, data[3])
							yield item
					if '>Tiếp' in r.text:
						item1 = Listitem()
						item1.label = f'Trang {str(int(next_page) + 1)}/{tongtrang}'
						item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
						item1.set_callback(search_hdvnnext, search_query, str(int(next_page) + 1), idsearch)
						yield item1
					yield tktrangmoi(search_query, idsearch)
			else:
				yield quangcao()
			dialog.update(100)
			dialog.close()
@Route.register
def hdvn_link(plugin, url=None, **kwargs):
	yield []
	if url is None:
		pass
	else:
		likehdvn(url)
		r = loginfhdvn().get(url)
		if 'fshare.vn' in r.text:
			soup = BeautifulSoup(r.content, 'html.parser')
			urls = list(dict.fromkeys([episode.get('href') for episode in soup.select('a.externalLink') if 'fshare.vn' in episode.get('href')]))
			length = len(urls)
			dialog = DialogProgress()
			dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
			dialog.update(5, f'Đang giải mã {length} dữ liệu...')
			if length>0:
				with ThreadPoolExecutor(length) as ex:
					future_to_url = {ex.submit(get_info_fs, url): url for url in urls}
					for future in as_completed(future_to_url):
						link = future_to_url[future]
						data = future.result()
						item = Listitem()
						item.label = data[0]
						item.info['plot'] = tb
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
						item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						if 'folder' in link:
							item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
						else:
							if Addon().getSetting('taifshare') == 'true':
								item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
							item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
						yield item
						dialog.update(50)
			dialog.update(100)
			dialog.close()
		else:
			yield quangcao()
@lru_cache(maxsize=None)
def trangmoi(url):
	item = Listitem()
	item.label = f'Trang khác (nhóm: {getInfoLabel("ListItem.Label")})'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
	item.set_callback(next_pagehdvn, url)
	return item
@lru_cache(maxsize=None)
def tktrangmoi(search_query, idsearch):
	item = Listitem()
	item.label = f'Trang khác (từ khoá: {getInfoLabel("ListItem.Label")})'
	item.info['plot'] = tb
	item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
	item.set_callback(next_searchhdvn, search_query, idsearch)
	return item