from codequick import Script, Route, Listitem, Resolver
from resources.lib.kedon import getlinkphongblack, postlinktimfs, getlinkvnm, __addonnoti__, tb, yttk
from concurrent.futures import ThreadPoolExecutor
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from xbmcaddon import Addon
from json import loads
from functools import lru_cache
import re
@lru_cache(maxsize=None)
def get_tkfs1(search_query):
	try:
		return getlinkphongblack(f'http://phongblack.me/search.php?author=phongblack&search={search_query}', 'http://www.google.com', -1)
	except:
		return getlinkphongblack(f'http://kodi.s2lsolutions.com/search.php?author=phongblack&search={search_query}', 'http://www.google.com', -1)
@lru_cache(maxsize=None)
def get_tkfs2(search_query):
	return postlinktimfs(f'https://api.timfshare.com/v1/string-query-search?query={search_query}', 'https://timfshare.com/', -1)
@lru_cache(maxsize=None)
def get_tkfs3(search_query):
	return getlinkvnm(f'http://thuvienhd.com/?feed=fsharejson&search={search_query}', 'https://thuvienhd.com/')
@lru_cache(maxsize=None)
def get_tkfs4():
	return getlinkvnm(f'http://thuvienhd.com/?feed=fsharejson&search=', 'https://thuvienhd.com/')
@Route.register
def searchfs(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		search_query = quote_plus(search_query)
		dp = DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		with ThreadPoolExecutor(4) as ex:
			f1 = ex.submit(get_tkfs1, search_query)
			f2 = ex.submit(get_tkfs2, search_query)
			f3 = ex.submit(get_tkfs3, search_query)
			f4 = ex.submit(get_tkfs4)
			result_f1 = f1.result()
			result_f2 = f2.result()
			result_f3 = f3.result()
			result_f4 = f4.result()
		dp.update(50)
		try:
			if result_f3 is not None and result_f4 is not None:
				if f3.result().content != f4.result().content:
					kqtvhd = f3.result().json()
					for t in kqtvhd:
						item = Listitem()
						item.label = t['title']
						item.info['plot'] = f'{t["title"]}\n{tb}'
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = item.art['fanart'] = t['image']
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
						yield item
		except:
			if result_f3 is not None and result_f4 is not None:
				if f3.result().content != f4.result().content:
					text = f3.result().text
					data = re.sub(r'<(.*?)\n','',text)
					jsm = loads(data)
					for t in jsm:
						item = Listitem()
						item.label = t['title']
						item.info['plot'] = f'{t["title"]}\n{tb}'
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = item.art['fanart'] = t['image']
						item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
						yield item
		try:
			d = [k for k in result_f1.json()['items'] if k['is_playable'] is False]
			for m in d:
				mota = f"{m['info']['plot']}\n{tb}" if 'info' in m else tb
				path = m['path']
				if '/file/' in path:
					item = Listitem()
					item.label = m['label']
					link = re.search(r"url=(\S+)", path)[1]
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
					item.info['plot'] = mota
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
					yield item
				elif '/folder/' in path:
					item = Listitem()
					item.label = m['label']
					link = re.search(r"url=(\S+)", path)[1]
					item.info['mediatype'] = 'episode'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
					item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
					item.info['plot'] = mota
					item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
					yield item
		except:
			pass
		try:
			m = [k for k in result_f2.json()['data'] if 'data' in result_f2.json()]
			for k in m:
				item = Listitem()
				item.label = k['name']
				item.info['plot'] = tb
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(item.label)
				item.art['thumb'] = f"https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={k['url']}&qzone=1&margin=1&size=400x400&ecc=L"
				item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
				if 'folder' in k['url']:
					item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), k['url'], 0)
				else:
					item.info['size'] = k['size']
					if Addon().getSetting('taifshare') == 'true':
						item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', k['url'])
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), k['url'], item.label)
				yield item
		except:
			pass
		dp.update(100)
		dp.close()
@Route.register
def index_pdx(plugin, **kwargs):
	yield []
	resptvhd = get_tkfs3('')
	try:
		kqtvhd = resptvhd.json()
		for t in kqtvhd:
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'movie'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['fanart'] = t['image']
			item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
			yield item
	except:
		text = resptvhd.text
		data = re.sub(r'<(.*?)\n','',text)
		jsm = loads(data)
		for dem, t in enumerate(jsm):
			item = Listitem()
			item.label = t['title']
			item.info['plot'] = f'{t["title"]}\n{tb}'
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(item.label)
			item.art['thumb'] = item.art['fanart'] = t['image']
			item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
			yield item