from codequick import Route, Listitem, Script, Resolver
from resources.lib.kedon import __addonnoti__, getlink, quangcao, tb, yttk, get_info_fs
from bs4 import BeautifulSoup
from xbmcgui import DialogProgress
from xbmcaddon import Addon
from urllib.parse import quote_plus
from concurrent.futures import ThreadPoolExecutor, as_completed
import re
@Route.register
def search_thuviencine(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		dp = DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		dp.update(5)
		url = 'https://thuviencine.com'
		resp = getlink(url, url, 7200)
		if (resp is not None):
			match = re.search(r'"nonce":"(.*?)"', resp.text)[1]
			urltv = f'http://thuviencine.com/wp-json/moviewp/search/?nonce={match}&keyword={quote_plus(search_query)}'
			r = getlink(urltv, url, 7200)
			if 'No results' in r.text:
				yield quangcao()
			else:
				for k in r.json().values():
					item = Listitem()
					item.label = k['title']
					item.info['plot'] = tb
					item.info['mediatype'] = 'movie'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['fanart'] = k['img']
					item.set_callback(thuviencine_link, k['url'])
					yield item
		else:
			yield quangcao()
		dp.update(100)
		dp.close()
@Route.register
def index_thuviencine(plugin, **kwargs):
	yield []
	yield Listitem.search(search_thuviencine)
	url = 'http://thuviencine.com'
	resp = getlink(url, url, 7200)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		for episode in soup.select('div.sidebar.sb-left a'):
			item = Listitem()
			phim = episode.get('href')
			item.label = episode.get_text(strip=True)
			item.info['plot'] = tb
			item.art['thumb'] = item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuviencine.png'
			item.set_callback(thuviencine_page, phim, 1)
			yield item
		for nhomtheloai in soup.select('nav.filters a'):
			item1 = Listitem()
			nhom = nhomtheloai.get('href')
			if tennhom:= nhomtheloai.get_text(strip=True):
				item1.label = tennhom
				item1.info['plot'] = tb
				item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/fshare/thuviencine.png'
				item1.set_callback(thuviencine_page, nhom, 1)
				yield item1
	else:
		yield quangcao()
@Route.register
def thuviencine_page(plugin, url=None, next_page=None, **kwargs):
	yield []
	if url is None or next_page is None:
		pass
	else:
		trangtiep = f'{url}page/{next_page}'
		resp = getlink(trangtiep, trangtiep, 7200)
		if (resp is not None):
			soup = BeautifulSoup(resp.content, 'html.parser')
			for episode in soup.select('div.item-container a[rel="bookmark"]'):
				item = Listitem()
				anh = episode.select('img')
				ndp = episode.select('p.movie-description')
				try:
					diem = episode.select_one('div.imdb-rating').get_text(strip=True)
				except:
					diem = 'N/A'
				for inf in ndp:
					noidung = f'Điểm IMDb: [COLOR yellow]{diem}[/COLOR]\n{inf.get_text(strip=True)}'
				linkphim = episode.get('href')
				for poster in anh:
					linkanh = poster.get('data-src')
				if ten:= episode.select_one('h2.movie-title').get_text(strip=True):
					item.label = ten
					item.info['plot'] = f'{noidung}\n{tb}'
					item.info['mediatype'] = 'movie'
					item.info['rating'] = 10.0
					item.info['trailer'] = yttk(item.label)
					item.art['thumb'] = item.art['fanart'] = linkanh
					item.set_callback(thuviencine_link, linkphim)
					yield item
			if 'resppages' in resp.text:
				item1 = Listitem()
				item1.label = f'Trang {next_page + 1}'
				item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
				item1.set_callback(thuviencine_page, url, next_page + 1)
				yield item1
		else:
			yield quangcao()
@Route.register
def thuviencine_link(plugin, url=None, **kwargs):
	yield []
	if url is None:
		pass
	else:
		resp = getlink(url, url, 7200)
		if (resp is not None):
			urls = re.findall(r'https?://(?:www\.)?fshare\.vn/(?:file|folder)/[^\s\'"]+', getlink(BeautifulSoup(resp.text, 'html.parser').select_one('li#download-button a').get('href'), url, 7200).text)
			length = len(urls)
			dialog = DialogProgress()
			dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
			dialog.update(5, f'Đang giải mã {length} dữ liệu...')
			if length>0:
				with ThreadPoolExecutor(length) as ex:
					future_to_url = {ex.submit(get_info_fs, url): url for url in urls}
					for future in as_completed(future_to_url):
						link = future_to_url[future]
						data = future.result()
						item = Listitem()
						item.label = data[0]
						item.info['plot'] = tb
						item.info['mediatype'] = 'episode'
						item.info['rating'] = 10.0
						item.info['trailer'] = yttk(item.label)
						item.art['thumb'] = f'https://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data={link}&qzone=1&margin=1&size=400x400&ecc=L'
						item.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/kodivnm.jpg'
						item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
						if 'folder' in link:
							item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0)
						else:
							item.info['size'] = data[1]
							if Addon().getSetting('taifshare') == 'true':
								item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
							item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, item.label)
						yield item
					dialog.update(50)
			dialog.update(100)
			dialog.close()
		else:
			yield quangcao()