from codequick import Route, Listitem, Resolver
from resources.lib.kedon import __addonnoti__, getlink, quangcao, tb, stream, referer
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
import re
@Route.register
def search_ophim(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		dp = DialogProgress()
		dp.create(__addonnoti__, 'Đang lấy dữ liệu...')
		dp.update(5)
		next_page = 1
		sr = quote_plus(search_query)
		url = f'https://ophim1.com/v1/api/tim-kiem?keyword={sr.replace(" ","+")}?page={next_page}'
		resp = getlink(url, url, 1800)
		if (resp is not None):
			kq = [k for k in resp.json()['data']['items'] if 'phim-18' not in str(k)]
			for k in kq:
				ten = f"{k['name']} - {k['lang']}"
				item = Listitem()
				item.label = ten
				item.info['plot'] = ten
				item.art['thumb'] = item.art['fanart'] = f"https://img.ophim1.com/uploads/movies/{k['thumb_url']}"
				item.set_callback(id_ophim, k['slug'])
				yield item
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
			item1.set_callback(ds_ophim, f'/tim-kiem?keyword={sr.replace(" ","+")}', next_page + 1)
			yield item1
		else:
			yield quangcao()
		dp.update(100)
		dp.close()
@Route.register
def index_ophim(plugin, **kwargs):
	yield Listitem.search(search_ophim)
	dulieu = {
	'Phim Mới': '/danh-sach/phim-moi',
	'Phim Bộ': '/danh-sach/phim-bo',
	'Phim Lẻ': '/danh-sach/phim-le',
	'TV Shows': '/danh-sach/tv-shows',
	'Hoạt Hình': '/danh-sach/hoat-hinh',
	'Phim phụ đề': '/danh-sach/subteam'
	}
	yield Listitem.from_dict(**{'label': 'Thể loại',
	'info': {'plot': tb},
	'art': {'thumb': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phimmienphi.png',
	'fanart': 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phimmienphi.png'},
	'callback': op_tl})
	yield Listitem.from_dict(**{'label': 'Quốc gia',
	'info':{'plot':tb},
	'art':{'thumb':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phimmienphi.png',
	'fanart':'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phimmienphi.png'},
	'callback': op_qg})
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phimmienphi.png'
		item.set_callback(ds_ophim, dulieu[k], 1)
		yield item
@Route.register
def op_tl(plugin, **kwargs):
	dulieu = {
	'Hành Động': '/the-loai/hanh-dong',
	'Tình Cảm': '/the-loai/tinh-cam',
	'Hài Hước': '/the-loai/hai-huoc',
	'Cổ Trang': '/the-loai/co-trang',
	'Tâm Lý': '/the-loai/tam-ly',
	'Hình Sự': '/the-loai/hinh-su',
	'Chiến Tranh': '/the-loai/chien-tranh',
	'Thể Thao': '/the-loai/the-thao',
	'Võ Thuật': '/the-loai/vo-thuat',
	'Viễn Tưởng': '/the-loai/vien-tuong',
	'Phiêu Lưu': '/the-loai/phieu-luu',
	'Khoa Học': '/the-loai/khoa-hoc',
	'Kinh Dị': '/the-loai/kinh-di',
	'Âm Nhạc': '/the-loai/am-nhac',
	'Thần Thoại': '/the-loai/than-thoai',
	'Tài Liệu': '/the-loai/tai-lieu',
	'Gia Đình': '/the-loai/gia-dinh',
	'Chính kịch': '/the-loai/chinh-kich',
	'Bí ẩn': '/the-loai/bi-an',
	'Học Đường': '/the-loai/hoc-duong',
	'Kinh Điển': '/the-loai/kinh-dien'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phimmienphi.png'
		item.set_callback(ds_ophim, dulieu[k], 1)
		yield item
@Route.register
def op_qg(plugin, **kwargs):
	dulieu = {
	'Trung Quốc': '/quoc-gia/trung-quoc',
	'Hàn Quốc': '/quoc-gia/han-quoc',
	'Nhật Bản': '/quoc-gia/nhat-ban',
	'Thái Lan': '/quoc-gia/thai-lan',
	'Âu Mỹ': '/quoc-gia/au-my',
	'Đài Loan': '/quoc-gia/dai-loan',
	'Hồng Kông': '/quoc-gia/hong-kong',
	'Ấn Độ': '/quoc-gia/an-do',
	'Anh': '/quoc-gia/anh',
	'Pháp': '/quoc-gia/phap',
	'Canada': '/quoc-gia/canada',
	'Quốc Gia Khác': '/quoc-gia/quoc-gia-khac',
	'Đức': '/quoc-gia/duc',
	'Tây Ban Nha': '/quoc-gia/tay-ban-nha',
	'Thổ Nhĩ Kỳ': '/quoc-gia/tho-nhi-ky',
	'Hà Lan': '/quoc-gia/ha-lan',
	'Indonesia': '/quoc-gia/indonesia',
	'Nga': '/quoc-gia/nga',
	'Mexico': '/quoc-gia/mexico',
	'Ba lan': '/quoc-gia/ba-lan',
	'Úc': '/quoc-gia/uc',
	'Thụy Điển': '/quoc-gia/thuy-dien',
	'Malaysia': '/quoc-gia/malaysia',
	'Brazil': '/quoc-gia/brazil',
	'Philippines': '/quoc-gia/philippines',
	'Bồ Đào Nha': '/quoc-gia/bo-dao-nha',
	'Ý': '/quoc-gia/y',
	'Đan Mạch': '/quoc-gia/dan-mach',
	'UAE': '/quoc-gia/uae',
	'Na Uy': '/quoc-gia/na-uy',
	'Thụy Sĩ': '/quoc-gia/thuy-si',
	'Châu Phi': '/quoc-gia/chau-phi',
	'Nam Phi': '/quoc-gia/nam-phi',
	'Ukraina': '/quoc-gia/ukraina',
	'Ả Rập Xê Út': '/quoc-gia/a-rap-xe-ut'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.info['plot'] = tb
		item.art['thumb'] = item.art['fanart'] = f'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/phimmienphi.png'
		item.set_callback(ds_ophim, dulieu[k], 1)
		yield item
@Route.register
def ds_ophim(plugin, match=None, next_page=None, **kwargs):
	yield []
	if match is None or next_page is None:
		pass
	else:
		n = f'https://ophim1.com/v1/api{match}?page={next_page}'
		resp = getlink(n, n, 1800)
		if (resp is not None):
			kq = [k for k in resp.json()['data']['items'] if 'phim-18' not in str(k)]
			for k in kq:
				ten = f"{k['name']} - {k['lang']}"
				item = Listitem()
				item.label = ten
				item.info['plot'] = ten
				item.art['thumb'] = item.art['fanart'] = f"https://img.ophim1.com/uploads/movies/{k['thumb_url']}"
				item.set_callback(id_ophim, k['slug'])
				yield item
			item1 = Listitem()
			item1.label = f'Trang {next_page + 1}'
			item1.art['thumb'] = item1.art['fanart'] = 'https://raw.githubusercontent.com/nguyenducmanh609/kodi.github.io/main/next.png'
			item1.set_callback(ds_ophim, match, next_page + 1)
			yield item1
		else:
			yield quangcao()
@Route.register
def id_ophim(plugin, idk=None, **kwargs):
	yield []
	if idk is None:
		pass
	else:
		t = f'https://ophim1.com/v1/api/phim/{idk}'
		resp = getlink(t, t, 1800)
		if (resp is not None):
			kq = resp.json()
			b = [[k1['server_name'], k2['name'], k2['link_m3u8'], k2['link_embed']] for k1 in kq['data']['item']['episodes'] for k2 in k1['server_data'] if 'link_m3u8' in k2]
			for k in b:
				item = Listitem()
				item.label = f"{k[0]} - Tập {k[1]} - {kq['data']['seoOnPage']['titleHead']}"
				item.info['plot'] = re.sub('<.*?>', '', kq['data']['item']['content'])
				item.art['thumb'] = item.art['fanart'] = kq['data']['seoOnPage']['seoSchema']['image']
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(k[2])}{referer(k[3])}', item.label, '')
				yield item
		else:
			yield quangcao()