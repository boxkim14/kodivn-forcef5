from urllib3 import PoolManager
from xbmc import executebuiltin
from xbmcaddon import Addon
from shutil import rmtree
from os.path import exists
from xbmcvfs import translatePath
from json import loads
def autorun_addon():
    executebuiltin('UpdateAddonRepos()')
    packages_path = translatePath('special://home/addons/packages')
    if Addon().getSetting('auto_run') == 'true':
        executebuiltin('RunAddon(plugin.video.vnmedia)')
    if Addon().getSetting('auto_noti') == 'true':
        try:
            r = PoolManager(timeout=20.0).request('GET', 'https://speedtest.vn/get-ip-info', headers={'user-agent': 'okhttp/4.10.0'}).data.decode('utf-8')
            a = ' '.join([c for c in reversed(loads(r).values())])
        except:
            a = 'Đây là Addon đã mod sẵn FSHARE VIP chỉ dùng được với VPN chỉ định'
        executebuiltin(f'Notification("Đây là Addon đã mod sẵn FSHARE VIP chỉ dùng được với VPN chỉ định", {a}, 10000, {Addon().getAddonInfo("icon")})')
    if exists(packages_path):
        try:
            rmtree(packages_path)
        except:
            pass
autorun_addon()